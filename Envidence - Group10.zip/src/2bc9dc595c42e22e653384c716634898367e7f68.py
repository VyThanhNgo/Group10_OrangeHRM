"""F04. Tạo đơn xin nghỉ
Nguồn testcase: sheet F04 (30 testcase LEV_APPLY_001 .. LEV_APPLY_030, mỗi testcase gồm 1 hoặc nhiều KB).

Cách tự động hóa (bộ chạy chỉ có phiên Admin):
- Admin cũng là một nhân viên nên dùng chính Admin để Apply Leave (fixture `admin_ready` tự cấp entitlement nếu thiếu).
- Case cần tài khoản ESS riêng (chưa có entitlement / chỉ còn 1 ngày phép / Admin duyệt-từ chối): fixture tự tạo
  nhân viên có tài khoản đăng nhập (tiền tố G10) rồi đăng nhập bằng context mới.
- Mỗi test tạo đơn dùng fixture `fresh`: huỷ (Cancel) các đơn Pending/Scheduled của Admin trong 2026-10-01..2026-12-31
  trước và sau test để chạy lại nhiều lần không bị trùng đơn / thiếu số dư. Các test độc lập nhau.
- Mỗi KB trong cùng một testcase được chạy tuần tự trong một hàm test (ghi chú bằng comment "# KBx").
"""
import re

import pytest
from playwright.sync_api import expect

from src.helpers import ohrm as h

VACATION = "CAN - Vacation"
PERSONAL = "CAN - Personal"
RANGE_FROM, RANGE_TO = "2026-10-01", "2026-12-31"
ESS_PASS = "Test@12345"
BAD_TEXT = re.compile(r"Internal Server Error|SQLSTATE|Stack ?trace|Exception", re.I)
DATE_FMT = "yyyy-mm-dd"  # tự đọc từ placeholder của ô ngày (demo đang dùng yyyy-dd-mm)
MONTHS = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]
NO_FORM_MSG = ("Tai khoan Admin chua duoc cap entitlement (khong co Leave Type) - "
               "can tao entitlement truoc (Leave > Entitlements > Add).")


# ======================= Helper riêng cho Leave =======================
def detect_fmt(page):
    global DATE_FMT
    ph = h.input(page, "From Date").get_attribute("placeholder")
    if ph and "yyyy" in ph:
        DATE_FMT = ph
    return DATE_FMT


def fmt(iso):
    """Đổi 'YYYY-MM-DD' sang định dạng ngày đang cấu hình trên hệ thống."""
    y, m, d = iso.split("-")
    return DATE_FMT.replace("yyyy", y).replace("mm", m).replace("dd", d)


def set_date(page, label, value):
    """Nhập ngày (ISO YYYY-MM-DD hoặc chuỗi tuỳ ý) vào ô date rồi click ra ngoài."""
    global DATE_FMT
    box = h.input(page, label)
    ph = box.get_attribute("placeholder")
    if ph and "yyyy" in ph:
        DATE_FMT = ph
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        value = fmt(value)
    box.click()
    box.press("Control+a")
    box.fill(value)
    page.locator("h5, h6").first.click()
    page.wait_for_timeout(300)


def pick(page, labels, option):
    """Chọn option trong dropdown; thử lần lượt các nhãn (nhãn thay đổi theo Partial Days)."""
    for lb in labels:
        g = h.group(page, lb)
        if g.count():
            g.locator(".oxd-select-text").click()
            page.locator(".oxd-select-dropdown .oxd-select-option", has_text=option).first.click()
            return
    raise AssertionError(f"Khong thay truong {labels}")


def set_time(page, label, hhmm, period):
    """Nhập giờ cho ô From/To của Specify Time."""
    g = h.group(page, label)
    box = g.locator("input[placeholder='hh:mm']").first
    box.click()
    picker = box.locator("xpath=../..").locator(".oxd-time-picker")
    expect(picker).to_be_visible(timeout=5000)

    hour_value, minute_value = hhmm.split(":")
    hour = picker.locator(".oxd-time-hour-input-text")
    minute = picker.locator(".oxd-time-minute-input-text")
    hour.fill(hour_value)
    minute.fill(minute_value)
    period_radio = picker.locator(f'input[type="radio"][value="{period}"]')
    period_radio.check()

    expect(hour).to_have_value(hour_value)
    expect(minute).to_have_value(minute_value)
    expect(period_radio).to_be_checked()


def open_apply(page):
    h.go(page, "/leave/applyLeave")
    expect(h.group(page, "Leave Type")).to_be_visible()
    detect_fmt(page)


def need_form(page):
    """Mở Apply Leave; skip nếu tài khoản chưa có entitlement (không có Leave Type)."""
    h.go(page, "/leave/applyLeave")
    if not h.group(page, "Leave Type").count():
        pytest.skip(NO_FORM_MSG)
    detect_fmt(page)


def with_balance_response(page, action):
    """Chạy action rồi chờ request lấy Leave Balance trả về (form hiện 0.00 trước khi số thật tải xong)."""
    seen = []

    def on_response(r):
        if "balance" in r.url.lower():
            seen.append(r.url)

    page.on("response", on_response)
    try:
        action()
        for _ in range(40):
            if seen:
                break
            page.wait_for_timeout(200)
    finally:
        page.remove_listener("response", on_response)
    h.ready(page)
    page.wait_for_timeout(300)


def select_type(page, leave_type, admin_name=None):
    for attempt in range(3):
        g = h.group(page, "Leave Type")
        g.locator(".oxd-select-text").click()
        opts = page.locator(".oxd-select-dropdown .oxd-select-option")
        try:
            opts.first.wait_for(state="visible", timeout=5000)
        except Exception:
            pass
        match = opts.filter(has_text=leave_type)
        if match.count():
            with_balance_response(page, lambda: match.first.click())
            return
        print(f"[select_type] '{leave_type}' missing, options={opts.all_inner_texts()} (try {attempt+1})")
        page.keyboard.press("Escape")
        if attempt == 1 and admin_name:      # balance probably 0 -> top up, then reload
            add_entitlement(page, admin_name, leave_type, 20)
            open_apply(page)
        else:
            page.reload()
            h.ready(page)
    raise AssertionError(f"'{leave_type}' not in Leave Type dropdown after retries")


def balance_text(page):
    g = h.group(page, "Leave Balance")
    expect(g).to_contain_text(re.compile(r"\d"))
    return re.sub(r"\s+", " ", g.inner_text()).strip()


def read_balance(page):
    txt = balance_text(page).replace("Leave Balance", "")
    return float(re.search(r"-?\d+(?:\.\d+)?", txt).group())


def fill_apply(page, leave_type, frm, to=None, duration=None, partial=None,
               start_dur=None, end_dur=None, comments=None):
    """Điền form Apply Leave (chưa bấm Apply)."""
    select_type(page, leave_type)
    set_date(page, "From Date", frm)
    set_date(page, "To Date", to or frm)
    multi = to is not None and to != frm
    if not multi and duration:
        pick(page, ["Duration"], duration)
    if multi and partial and partial != "None":
        pick(page, ["Partial Days"], partial)
        if partial == "All Days":
            pick(page, ["Duration"], duration)
        elif partial == "Start Day Only":
            pick(page, ["Start Day Duration", "Duration", "Start Day"], duration)
        elif partial == "End Day Only":
            pick(page, ["End Day Duration", "Duration", "End Day"], duration)
        elif partial == "Start and End Day":
            pick(page, ["Start Day Duration", "Start Day"], start_dur)
            pick(page, ["End Day Duration", "End Day"], end_dur)
    if comments is not None:
        h.input(page, "Comments").fill(comments)


def submit(page):
    h.btn(page, "Apply").click()


def apply_ok(page, *args, **kwargs):
    """Mở form, điền, bấm Apply và kiểm tra thông báo thành công."""
    open_apply(page)
    fill_apply(page, *args, **kwargs)
    submit(page)
    h.expect_success(page)
    h.ready(page)


def no_success_toast(page):
    assert h.toast(page).filter(has_text=re.compile("Successfully", re.I)).count() == 0


def expect_rejected(page, pattern):
    """Hệ thống từ chối: hiện dialog/toast/lỗi khớp pattern và không có toast Success."""
    msg = page.locator(
        ".oxd-dialog-container-default, .oxd-toast, .oxd-input-field-error-message, .oxd-text"
    ).filter(has_text=re.compile(pattern, re.I)).first
    expect(msg).to_be_visible()
    no_success_toast(page)


def set_statuses(page, statuses):
    g = h.group(page, "Show Leave with Status")
    for _ in range(10):  # bỏ các status mặc định (My Leave mặc định có cả Cancelled...)
        chip_x = g.locator(".oxd-chip .oxd-chip-icon, .oxd-chip .bi-x")
        if chip_x.count() == 0:
            break
        chip_x.first.click()
        page.wait_for_timeout(150)
    for st in statuses:
        if g.locator(".oxd-chip", has_text=st).count():
            continue
        if not page.locator(".oxd-select-dropdown").is_visible():
            g.locator(".oxd-select-text").click()
        page.locator(".oxd-select-dropdown .oxd-select-option", has_text=st).first.click()
        page.wait_for_timeout(200)


def search_my_leave(page, frm, to, statuses=("Pending Approval",)):
    h.go(page, "/leave/viewMyLeaveList")
    set_date(page, "From Date", frm)
    set_date(page, "To Date", to)
    set_statuses(page, statuses)
    h.btn(page, "Search").click()
    h.ready(page)
    try:
        return h.record_count(page)
    except Exception:
        return 0


def cell(page, row, header):
    heads = [re.sub(r"\s+", " ", t).strip()
             for t in page.locator(".oxd-table-header .oxd-table-header-cell").all_inner_texts()]
    idx = next(i for i, t in enumerate(heads) if header in t)
    return row.locator(".oxd-table-cell").nth(idx).inner_text().strip()


def my_leave_row(page, date_text, statuses=("Pending Approval",)):
    search_my_leave(page, RANGE_FROM, RANGE_TO, statuses)
    row = (h.rows(page).filter(has_text=fmt(date_text))
           .filter(has_text=re.compile("|".join(statuses))).first)
    expect(row).to_be_visible()
    return row


def active_rows(page, iso_date):
    """Các dòng My Leave của ngày đó còn hiệu lực (Pending Approval / Scheduled)."""
    return (h.rows(page).filter(has_text=fmt(iso_date))
            .filter(has_text=re.compile("Pending Approval|Scheduled")))


def cancel_my_leaves(page, frm=RANGE_FROM, to=RANGE_TO):
    """Huỷ mọi đơn Pending/Scheduled của tài khoản đang đăng nhập trong khoảng ngày test."""
    for _ in range(40):
        search_my_leave(page, frm, to, ("Pending Approval", "Scheduled"))
        btn = h.rows(page).locator("button", has_text="Cancel")
        if btn.count() == 0:
            return
        btn.first.click()
        try:
            h.expect_success(page)
        except Exception:  # toast có thể hiện/ẩn quá nhanh; vòng lặp sau sẽ tự kiểm tra lại
            pass
        page.wait_for_timeout(800)


def safe_cancel_my_leaves(page):
    """Dọn dẹp 'cố gắng hết sức': lỗi dọn dẹp không được làm test bị ERROR."""
    try:
        cancel_my_leaves(page)
    except Exception as e:  # noqa: BLE001
        print(f"[fresh] Không huỷ hết đơn cũ: {str(e).splitlines()[0]}")


def leave_list_search(page, frm, to, statuses, employee=None):
    h.go(page, "/leave/viewLeaveList")
    set_date(page, "From Date", frm)
    set_date(page, "To Date", to)
    set_statuses(page, statuses)
    if employee:
        h.autocomplete(page, "Employee Name", employee)
    h.btn(page, "Search").click()
    h.ready(page)
    try:
        h.record_count(page)
    except Exception:
        pass


def pick_calendar_date(page, label, y, m, d):
    h.group(page, label).locator(".oxd-date-input-icon").click()
    cal = page.locator(".oxd-calendar-wrapper")
    expect(cal).to_be_visible()
    for _ in range(36):
        mon = cal.locator(".oxd-calendar-selector-month").inner_text().strip()
        yr = int(cal.locator(".oxd-calendar-selector-year").inner_text().strip())
        cur, want = yr * 12 + MONTHS.index(mon), y * 12 + (m - 1)
        if cur == want:
            break
        cal.locator(".oxd-calendar-header .bi-chevron-" + ("right" if cur < want else "left")).click()
    cal.locator(".oxd-calendar-date", has_text=re.compile(rf"^{d}$")).first.click()


# ---------- Dữ liệu nền (Admin) ----------
def add_entitlement(page, employee, leave_type, days):
    h.go(page, "/leave/addLeaveEntitlement")
    h.autocomplete(page, "Employee Name", employee)
    h.select_option(page, "Leave Type", leave_type)
    h.input(page, "Entitlement").fill(str(days))
    h.btn(page, "Save").click()
    dlg = page.locator(".oxd-dialog-container-default")
    try:
        dlg.wait_for(state="visible", timeout=5000)
        dlg.locator("button", has_text="Confirm").click()
    except Exception:
        pass
    h.expect_success(page)
    h.ready(page)


def ensure_balance(page, name, leave_type, minimum):
    """Đảm bảo nhân viên có entitlement >= minimum cho leave_type (chỉ cấp thêm khi thiếu)."""
    h.go(page, "/leave/applyLeave")
    current = None
    if h.group(page, "Leave Type").count():
        h.group(page, "Leave Type").locator(".oxd-select-text").click()
        options = page.locator(".oxd-select-dropdown .oxd-select-option")
        options.first.wait_for(state="visible")
        match = options.filter(has_text=leave_type)
        if match.count():
            with_balance_response(page, lambda: match.first.click())
            current = read_balance(page)
    if current is None or current < minimum:
        add_entitlement(page, name, leave_type, minimum)


def my_entitlement_days(pg, leave_type):
    """Tổng số ngày entitlement của leave_type tại Leave > Entitlements > My Entitlements."""
    h.go(pg, "/leave/viewMyLeaveEntitlements")
    rows = h.rows(pg).filter(has_text=leave_type)
    expect(rows.first).to_be_visible()
    total = 0.0
    for i in range(rows.count()):
        total += float(re.search(r"\d+(?:\.\d+)?", cell(pg, rows.nth(i), "Days")).group())
    return total


def make_user(admin_page, entitlements):
    """Tạo nhân viên có tài khoản ESS + cấp entitlement. Trả về dict thông tin đăng nhập."""
    first, last = h.uniq("G10Les"), "Apply"
    username = h.uniq("g10ess")
    h.go(admin_page, "/pim/addEmployee")
    admin_page.locator('input[name="firstName"]').fill(first)
    admin_page.locator('input[name="lastName"]').fill(last)
    admin_page.locator(".oxd-switch-input").first.click()
    h.input(admin_page, "Username").fill(username)
    h.input(admin_page, "Password").fill(ESS_PASS)
    h.input(admin_page, "Confirm Password").fill(ESS_PASS)
    h.btn(admin_page, "Save").click()
    admin_page.wait_for_url(re.compile(r"pim/viewPersonalDetails"), timeout=60_000)
    h.ready(admin_page)
    full = f"{first} {last}"
    for leave_type, days in entitlements:
        add_entitlement(admin_page, full, leave_type, days)
    return {"username": username, "password": ESS_PASS, "full": full}


def login_as(browser, user):
    ctx, pg = h.anonymous(browser)
    pg.set_default_timeout(30_000)
    pg.set_default_navigation_timeout(60_000)
    pg.goto("/web/index.php/auth/login")
    pg.get_by_placeholder("Username").fill(user["username"])
    pg.get_by_placeholder("Password").fill(user["password"])
    pg.get_by_role("button", name="Login").click()
    expect(pg).to_have_url(re.compile(r"dashboard/index"))
    return ctx, pg


def exhaust_personal(pg):
    """Pre của e01: đưa CAN - Personal của user về 0 ngày (nếu còn)."""
    open_apply(pg)
    select_type(pg, PERSONAL)
    if read_balance(pg) > 0:
        fill_apply(pg, PERSONAL, "2026-12-01", duration="Full Day")
        submit(pg)
        h.expect_success(pg)
        h.ready(pg)


# ======================= Fixtures =======================
@pytest.fixture(scope="module")
def admin_page(browser, admin_storage_state):
    ctx = browser.new_context(storage_state=admin_storage_state, base_url=h.BASE_URL, viewport=h.VIEWPORT)
    pg = ctx.new_page()
    pg.set_default_timeout(30_000)
    pg.set_default_navigation_timeout(60_000)
    yield pg
    ctx.close()


@pytest.fixture(scope="module", autouse=True)
def admin_ready(admin_page):
    """Đảm bảo Admin có entitlement CAN - Vacation / CAN - Personal. Trả về tên hiển thị của Admin."""
    h.go(admin_page, "/dashboard/index")
    name = admin_page.locator(".oxd-userdropdown-name").inner_text().strip()
    ensure_balance(admin_page, name, VACATION, 20)
    ensure_balance(admin_page, name, PERSONAL, 5)
    return name


@pytest.fixture
def fresh(page, admin_ready):
    safe_cancel_my_leaves(page)
    ensure_balance(page, admin_ready, VACATION, 20)   # re-check before every test
    yield
    safe_cancel_my_leaves(page)


@pytest.fixture(scope="module")
def ess_noent(admin_page):
    return make_user(admin_page, [])


@pytest.fixture  # function-scope: mỗi test dùng 1 user mới (còn đúng 1 ngày Personal) nên các test độc lập nhau
def ess_one_day(admin_page):
    return make_user(admin_page, [(PERSONAL, 1)])


@pytest.fixture(scope="module")
def ess_vac(admin_page):
    return make_user(admin_page, [(VACATION, 20), (PERSONAL, 3)])


# ======================= F04.1. Truy cập và hiển thị form Apply Leave =======================
@pytest.mark.tc(
    steps=(
        "1. Truy cập https://opensource-demo.orangehrmlive.com/web/index.php/auth/login.\n"
        "2. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "3. Click menu \"Leave\" ở thanh bên trái.\n"
        "4. Click tab \"Apply\"."
    ),
    expected=(
        "1. Đăng nhập thành công, hiển thị Dashboard.\n"
        "2. Chuyển sang trang Apply Leave (URL chứa /leave/applyLeave), tiêu đề \"Apply Leave\".\n"
        "3. Trang tải đầy đủ, không báo lỗi."
    ),
)
def test_LEV_APPLY_001_dieu_huong_tu_menu(page):
    "LEV_APPLY_001 | Điều hướng đến màn hình Apply Leave từ menu Leave"
    h.go(page, "/dashboard/index")
    h.open_menu(page, "Leave")
    h.open_tab(page, "Apply")
    expect(page).to_have_url(re.compile(r"leave/applyLeave"))
    expect(page.get_by_role("heading", name="Apply Leave")).to_be_visible()


@pytest.mark.tc(
    steps=(
        "1. Mở cửa sổ ẩn danh.\n"
        "2. Truy cập https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave."
    ),
    expected=(
        "1. Hệ thống chuyển về trang Login.\n"
        "2. Không hiển thị nội dung form Apply Leave."
    ),
)
def test_LEV_APPLY_002_truy_cap_khi_chua_dang_nhap(browser):
    "LEV_APPLY_002 | Truy cập trực tiếp URL Apply Leave khi chưa đăng nhập"
    ctx, anon = h.anonymous(browser)
    try:
        anon.goto("/web/index.php/leave/applyLeave")
        expect(anon).to_have_url(re.compile(r"auth/login"))
        expect(h.group(anon, "Leave Type")).to_have_count(0)
    finally:
        ctx.close()


@pytest.mark.tc(
    steps=(
        "KB1 - Hiển thị bố cục form Apply Leave:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Quan sát form.\n"
        "KB2 - Hiển thị giá trị mặc định của form:\n"
        "1. Quan sát các trường khi vừa vào form.\n"
        "KB3 - Hiển thị danh sách Leave Type trong dropdown:\n"
        "1. Click dropdown Leave Type."
    ),
    expected=(
        "KB1:\n"
        "1. Hiển thị các trường: Leave Type (dropdown), From Date, To Date, Comments và nút [Apply].\n"
        "2. Trường bắt buộc có dấu (*), có chú thích \"* Required\".\n"
        "3. Bố cục đúng, không vỡ layout.\n"
        "KB2:\n"
        "1. Leave Type hiển thị \"-- Select --\".\n"
        "2. From Date, To Date trống, placeholder \"yyyy-mm-dd\"; Comments trống.\n"
        "3. Chưa hiển thị các trường Partial Days / Duration.\n"
        "KB3:\n"
        "1. Danh sách chỉ gồm các loại phép nhân viên có entitlement trong kỳ nghỉ hiện tại (VD: CAN - Vacation, CAN - Personal).\n"
        "2. Có thể cuộn/chọn được từng mục."
    ),
)
def test_LEV_APPLY_003_bo_cuc_mac_dinh_leave_type(page):
    "LEV_APPLY_003 | Hiển thị bố cục, giá trị mặc định của form Apply Leave và danh sách Leave Type"
    # KB1 - Bố cục form
    need_form(page)
    h.expect_labels(page, ["Leave Type", "From Date", "To Date", "Comments"])
    expect(h.btn(page, "Apply")).to_be_visible()

    # KB2 - Giá trị mặc định
    assert "Select" in h.selected_text(page, "Leave Type")
    expect(h.input(page, "Comments")).to_have_value("")
    expect(h.input(page, "From Date")).to_have_value("")
    expect(h.input(page, "To Date")).to_have_value("")
    expect(h.group(page, "Partial Days")).to_have_count(0)
    expect(h.group(page, "Duration")).to_have_count(0)

    # KB3 - Danh sách Leave Type
    h.group(page, "Leave Type").locator(".oxd-select-text").click()
    assert page.locator(".oxd-select-dropdown .oxd-select-option").count() > 1
    page.keyboard.press("Escape")


@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng ESS mới chưa có entitlement (ess_new / Test@12345).\n"
        "2. Vào menu Leave > Apply."
    ),
    expected=(
        "1. Hiển thị thông báo \"No Leave Types with Leave Balance\".\n"
        "2. Không thể tạo đơn nghỉ."
    ),
)
def test_LEV_APPLY_004_chua_co_entitlement(browser, ess_noent):
    "LEV_APPLY_004 | Nhân viên chưa được cấp entitlement nào"
    ctx, pg = login_as(browser, ess_noent)
    try:
        h.go(pg, "/leave/applyLeave")
        expect(pg.get_by_text(re.compile("No Leave Types with Leave Balance", re.I)).first).to_be_visible()
        expect(h.btn(pg, "Apply")).to_have_count(0)
    finally:
        ctx.close()


# ======================= F04.2. Chọn Leave Type và Leave Balance =======================
@pytest.mark.tc(
    steps=(
        "KB1 - Leave Balance hiển thị đúng khi chọn Leave Type:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào Leave > Entitlements > My Entitlements, ghi nhận số ngày còn lại của \"CAN - Vacation\".\n"
        "3. Vào menu Leave > Apply.\n"
        "4. Chọn Leave Type \"CAN - Vacation\".\n"
        "KB2 - Đổi Leave Type thì Leave Balance cập nhật theo:\n"
        "1. Chọn \"CAN - Vacation\", quan sát Leave Balance.\n"
        "2. Đổi sang \"CAN - Personal\"."
    ),
    expected=(
        "KB1:\n"
        "1. Leave Balance hiển thị đúng số ngày còn lại (đơn vị Day(s)) khớp với dữ liệu ở My Entitlements.\n"
        "KB2:\n"
        "1. Leave Balance thay đổi đúng theo từng Leave Type."
    ),
)
def test_LEV_APPLY_005_leave_balance_doi_leave_type(browser, ess_vac):
    "LEV_APPLY_005 | Leave Balance hiển thị đúng và cập nhật khi đổi Leave Type"
    ctx, pg = login_as(browser, ess_vac)
    try:
        # KB1
        exp_v = my_entitlement_days(pg, VACATION)
        assert exp_v == pytest.approx(20.0)
        open_apply(pg)
        select_type(pg, VACATION)
        assert "Day" in balance_text(pg)
        assert read_balance(pg) == pytest.approx(exp_v)

        # KB2
        exp_p = my_entitlement_days(pg, PERSONAL)
        open_apply(pg)
        select_type(pg, VACATION)
        assert read_balance(pg) == pytest.approx(exp_v)
        select_type(pg, PERSONAL)
        assert read_balance(pg) == pytest.approx(exp_p)
        assert exp_v != exp_p
    finally:
        ctx.close()


# ======================= F04.3. Tạo đơn nghỉ thành công =======================
@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn nghỉ 1 ngày (Full Day) có nhập Comments:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn Leave Type \"CAN - Vacation\".\n"
        "4. Nhập From Date = 2026-11-02 (thứ Hai); To Date = 2026-11-02.\n"
        "5. Chọn Duration \"Full Day\".\n"
        "6. Nhập Comments \"Nghỉ việc riêng\".\n"
        "7. Click [Apply].\n"
        "KB2 - Tạo đơn nghỉ 1 ngày không nhập Comments:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = To Date = 2026-11-03, Duration \"Full Day\".\n"
        "3. Để trống Comments, click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hiển thị thông báo \"Successfully Saved\".\n"
        "2. Đơn được tạo với trạng thái \"Pending Approval\" (kiểm tra tại My Leave).\n"
        "KB2:\n"
        "1. Tạo đơn thành công (Comments không bắt buộc), trạng thái Pending Approval."
    ),
)
def test_LEV_APPLY_006_nghi_1_ngay_full_day(page, fresh):
    "LEV_APPLY_006 | Tạo đơn nghỉ 1 ngày (Full Day) có và không nhập Comments"
    # KB1
    apply_ok(page, VACATION, "2026-11-02", duration="Full Day", comments="Nghỉ việc riêng")
    expect(my_leave_row(page, "2026-11-02")).to_contain_text("Pending Approval")
    # KB2
    apply_ok(page, VACATION, "2026-11-03", duration="Full Day")
    expect(my_leave_row(page, "2026-11-03")).to_contain_text("Pending Approval")


@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn nghỉ nửa ngày buổi sáng:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = To Date = 2026-11-04.\n"
        "5. Chọn Duration \"Half Day - Morning\".\n"
        "6. Click [Apply].\n"
        "KB2 - Tạo đơn nghỉ nửa ngày buổi chiều:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = To Date = 2026-11-05.\n"
        "3. Chọn Duration \"Half Day - Afternoon\".\n"
        "4. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Tạo đơn thành công.\n"
        "2. Tại My Leave, Number of Days = 0.50, Status = Pending Approval.\n"
        "KB2:\n"
        "1. Tạo đơn thành công.\n"
        "2. Tại My Leave, Number of Days = 0.50, Status = Pending Approval."
    ),
)
def test_LEV_APPLY_007_nghi_nua_ngay(page, fresh):
    "LEV_APPLY_007 | Tạo đơn nghỉ nửa ngày buổi sáng và buổi chiều"
    # KB1
    apply_ok(page, VACATION, "2026-11-04", duration="Half Day - Morning")
    row = my_leave_row(page, "2026-11-04")
    assert cell(page, row, "Number of Days") == "0.50"
    expect(row).to_contain_text("Pending Approval")
    # KB2
    apply_ok(page, VACATION, "2026-11-05", duration="Half Day - Afternoon")
    row = my_leave_row(page, "2026-11-05")
    assert cell(page, row, "Number of Days") == "0.50"
    expect(row).to_contain_text("Pending Approval")


@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn nghỉ theo giờ (Specify Time):\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = To Date = 2026-11-06.\n"
        "5. Chọn Duration \"Specify Time\", nhập From 09:00 AM, To 12:00 PM.\n"
        "6. Click [Apply].\n"
        "KB2 - Specify Time với giờ kết thúc nhỏ hơn giờ bắt đầu:\n"
        "1. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-14.\n"
        "2. Chọn Duration \"Specify Time\", From 03:00 PM, To 09:00 AM.\n"
        "3. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hiển thị tổng thời lượng (3.00 giờ).\n"
        "2. Tạo đơn thành công, đơn thể hiện đúng khoảng thời gian đã chọn.\n"
        "KB2:\n"
        "1. Hiển thị thông báo lỗi giờ không hợp lệ.\n"
        "2. Không tạo đơn."
    ),
)
def test_LEV_APPLY_008_nghi_theo_gio(page, fresh):
    "LEV_APPLY_008 | Tạo đơn nghỉ theo giờ (Specify Time) với giờ hợp lệ và giờ kết thúc nhỏ hơn giờ bắt đầu"
    # KB1
    open_apply(page)
    fill_apply(page, VACATION, "2026-11-06", duration="Specify Time")
    set_time(page, "From", "09:00", "AM")
    set_time(page, "To", "12:00", "PM")
    expect(page.locator("form.oxd-form")).to_contain_text(re.compile(r"(?<![\d.])3\.00(?!\d)"))
    submit(page)
    h.expect_success(page)
    h.ready(page)
    expect(my_leave_row(page, "2026-11-06")).to_contain_text("Pending Approval")

    # KB2
    open_apply(page)
    fill_apply(page, VACATION, "2026-12-14", duration="Specify Time")
    set_time(page, "From", "03:00", "PM")
    set_time(page, "To", "09:00", "AM")
    submit(page)
    msg = page.locator(".oxd-input-field-error-message, .oxd-dialog-container-default, .oxd-toast").first
    expect(msg).to_be_visible()
    no_success_toast(page)
    assert search_my_leave(page, "2026-12-14", "2026-12-14", ("Pending Approval", "Scheduled")) == 0


@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = To Date = 2026-10-20 (đã qua), Duration \"Full Day\".\n"
        "5. Click [Apply]."
    ),
    expected="1. Hệ thống chấp nhận tạo đơn (OrangeHRM không chặn ngày quá khứ), trạng thái Pending Approval.",
)
def test_LEV_APPLY_009_nghi_ngay_qua_khu(page, fresh):
    "LEV_APPLY_009 | Tạo đơn nghỉ cho ngày trong quá khứ"
    apply_ok(page, VACATION, "2026-10-20", duration="Full Day")
    expect(my_leave_row(page, "2026-10-20")).to_contain_text("Pending Approval")


@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn nghỉ 3 ngày làm việc liên tiếp:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = 2026-11-09, To Date = 2026-11-11.\n"
        "5. Chọn Partial Days \"None\".\n"
        "6. Click [Apply].\n"
        "KB2 - Tạo đơn nghỉ khoảng ngày có thứ Bảy, Chủ nhật:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-11-13 (thứ Sáu), To Date = 2026-11-16 (thứ Hai).\n"
        "3. Chọn Partial Days \"None\", click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Tạo đơn thành công.\n"
        "2. Tại My Leave, Number of Days = 3.00, Status = Pending Approval.\n"
        "KB2:\n"
        "1. Chỉ tính 2 ngày làm việc (thứ Sáu, thứ Hai); Number of Days = 2.00.\n"
        "2. Thứ Bảy, Chủ nhật không bị trừ vào số dư."
    ),
)
def test_LEV_APPLY_010_nghi_nhieu_ngay_lien_tiep(page, fresh):
    "LEV_APPLY_010 | Tạo đơn nghỉ nhiều ngày liên tiếp (3 ngày làm việc; khoảng ngày có thứ Bảy, Chủ nhật)"
    # KB1 - chọn ngày trực tiếp trên lịch
    open_apply(page)
    select_type(page, VACATION)
    pick_calendar_date(page, "From Date", 2026, 11, 9)
    pick_calendar_date(page, "To Date", 2026, 11, 11)
    expect(h.input(page, "From Date")).to_have_value(fmt("2026-11-09"))
    expect(h.input(page, "To Date")).to_have_value(fmt("2026-11-11"))
    submit(page)
    h.expect_success(page)
    h.ready(page)
    row = my_leave_row(page, "2026-11-09")
    assert cell(page, row, "Number of Days") == "3.00"
    expect(row).to_contain_text("Pending Approval")

    # KB2
    apply_ok(page, VACATION, "2026-11-13", to="2026-11-16", partial="None")
    row = my_leave_row(page, "2026-11-13")
    assert cell(page, row, "Number of Days") == "2.00"


# ---------- Partial Days ----------
@pytest.mark.tc(
    steps=(
        "KB1 - Hiển thị trường Partial Days khi chọn khoảng nhiều ngày:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = 2026-11-17, To Date = 2026-11-18.\n"
        "5. Click dropdown Partial Days.\n"
        "KB2 - Partial Days = All Days:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-11-17, To Date = 2026-11-18.\n"
        "3. Chọn Partial Days \"All Days\", Duration \"Half Day - Morning\".\n"
        "4. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Trường Partial Days xuất hiện.\n"
        "2. Các lựa chọn: All Days, Start Day Only, End Day Only, Start and End Day, None.\n"
        "KB2:\n"
        "1. Tạo đơn thành công.\n"
        "2. Mỗi ngày tính 0.50, tổng Number of Days = 1.00."
    ),
)
def test_LEV_APPLY_011_partial_days_all_days(page, fresh):
    "LEV_APPLY_011 | Hiển thị trường Partial Days và chọn Partial Days = All Days"
    # KB1
    open_apply(page)
    select_type(page, VACATION)
    set_date(page, "From Date", "2026-11-17")
    set_date(page, "To Date", "2026-11-18")
    expect(h.group(page, "Partial Days")).to_be_visible()
    h.group(page, "Partial Days").locator(".oxd-select-text").click()
    opts = [o.strip() for o in page.locator(".oxd-select-dropdown .oxd-select-option").all_inner_texts()]
    # Demo OrangeHRM 5.9: không có mục "None", giá trị "không chia nửa ngày" là "-- Select --"
    for expected in ["All Days", "Start Day Only", "End Day Only", "Start and End Day"]:
        assert expected in opts, f"Thieu lua chon {expected}: {opts}"
    page.keyboard.press("Escape")

    # KB2
    apply_ok(page, VACATION, "2026-11-17", to="2026-11-18", partial="All Days", duration="Half Day - Morning")
    row = my_leave_row(page, "2026-11-17")
    assert cell(page, row, "Number of Days") == "1.00"


@pytest.mark.tc(
    steps=(
        "KB1 - Partial Days = Start Day Only:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = 2026-11-19, To Date = 2026-11-20.\n"
        "5. Chọn Partial Days \"Start Day Only\", Duration \"Half Day - Afternoon\".\n"
        "6. Click [Apply].\n"
        "KB2 - Partial Days = End Day Only:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-11-23, To Date = 2026-11-24.\n"
        "3. Chọn Partial Days \"End Day Only\", Duration \"Half Day - Morning\".\n"
        "4. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Tạo đơn thành công.\n"
        "2. Ngày đầu 0.50, ngày cuối 1.00; tổng Number of Days = 1.50.\n"
        "KB2:\n"
        "1. Tạo đơn thành công.\n"
        "2. Ngày đầu 1.00, ngày cuối 0.50; tổng Number of Days = 1.50."
    ),
)
def test_LEV_APPLY_012_partial_days_start_end_only(page, fresh):
    "LEV_APPLY_012 | Partial Days = Start Day Only và End Day Only"
    # KB1
    apply_ok(page, VACATION, "2026-11-19", to="2026-11-20", partial="Start Day Only", duration="Half Day - Afternoon")
    row = my_leave_row(page, "2026-11-19")
    assert cell(page, row, "Number of Days") == "1.50"
    # KB2
    apply_ok(page, VACATION, "2026-11-23", to="2026-11-24", partial="End Day Only", duration="Half Day - Morning")
    row = my_leave_row(page, "2026-11-23")
    assert cell(page, row, "Number of Days") == "1.50"


@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = 2026-11-25, To Date = 2026-11-27.\n"
        "5. Chọn Partial Days \"Start and End Day\"; Start Day \"Half Day - Morning\", End Day \"Half Day - Afternoon\".\n"
        "6. Click [Apply]."
    ),
    expected=(
        "1. Tạo đơn thành công.\n"
        "2. Tổng Number of Days = 2.00 (0.5 + 1 + 0.5)."
    ),
)
def test_LEV_APPLY_013_partial_days_start_and_end(page, fresh):
    "LEV_APPLY_013 | Partial Days = Start and End Day"
    apply_ok(page, VACATION, "2026-11-25", to="2026-11-27", partial="Start and End Day",
             start_dur="Half Day - Morning", end_dur="Half Day - Afternoon")
    row = my_leave_row(page, "2026-11-25")
    assert cell(page, row, "Number of Days") == "2.00"


# ---------- Dữ liệu sau khi tạo ----------
@pytest.mark.tc(
    steps=(
        "KB1 - Đơn mới hiển thị đúng tại My Leave:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > My Leave.\n"
        "3. Lọc From Date 2026-11-01, To Date 2026-11-30, Status \"Pending Approval\", click [Search].\n"
        "KB2 - Đơn mới hiển thị trong Leave List của Admin:\n"
        "1. Đăng nhập bằng tài khoản Admin (Admin / admin123).\n"
        "2. Vào menu Leave > Leave List.\n"
        "3. Lọc Status \"Pending Approval\", Employee Name = nhân viên ESS, click [Search]."
    ),
    expected=(
        "KB1:\n"
        "1. Có dòng: Date 2026-11-02, Leave Type CAN - Vacation, Number of Days 1.00, Status Pending Approval, Comments \"Nghỉ việc riêng\".\n"
        "KB2:\n"
        "1. Hiển thị đơn ngày 2026-11-02 của nhân viên ESS với Status Pending Approval.\n"
        "2. Có các nút [Approve], [Reject]."
    ),
)
def test_LEV_APPLY_014_don_moi_my_leave_leave_list(page, browser, fresh, ess_vac):
    "LEV_APPLY_014 | Đơn mới hiển thị đúng tại My Leave và Leave List của Admin"
    # KB1 - (Admin đóng vai nhân viên)
    apply_ok(page, VACATION, "2026-11-02", duration="Full Day", comments="Nghỉ việc riêng")
    row = my_leave_row(page, "2026-11-02")
    assert fmt("2026-11-02") in cell(page, row, "Date")
    assert VACATION in cell(page, row, "Leave Type")
    assert cell(page, row, "Number of Days") == "1.00"
    assert "Pending Approval" in cell(page, row, "Status")
    assert "Nghỉ việc riêng" in cell(page, row, "Comments")

    # KB2 - nhân viên ESS tạo đơn, Admin kiểm tra ở Leave List
    ctx, ess_page = login_as(browser, ess_vac)
    try:
        apply_ok(ess_page, VACATION, "2026-11-02", duration="Full Day")
        expect(my_leave_row(ess_page, "2026-11-02")).to_contain_text("Pending Approval")

        leave_list_search(page, "2026-11-01", "2026-11-30", ["Pending Approval"], employee=ess_vac["full"])
        row = (h.rows(page).filter(has_text=fmt("2026-11-02"))
               .filter(has_text=ess_vac["full"]).filter(has_text="Pending Approval").first)
        expect(row).to_be_visible()
        expect(row).to_contain_text(VACATION)
        expect(row.locator("button", has_text="Approve")).to_be_visible()
        expect(row.locator("button", has_text="Reject")).to_be_visible()
    finally:
        ctx.close()


@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\", so sánh Leave Balance với giá trị trước khi tạo c01."
    ),
    expected="1. Leave Balance thay đổi đúng theo quy tắc hệ thống sau khi có đơn mới.",
)
def test_LEV_APPLY_015_balance_sau_khi_tao_don(page, fresh):
    "LEV_APPLY_015 | Leave Balance cập nhật sau khi tạo đơn"
    open_apply(page)
    select_type(page, VACATION)
    before = read_balance(page)
    apply_ok(page, VACATION, "2026-11-02", duration="Full Day")
    open_apply(page)
    select_type(page, VACATION)
    # [Q2] Giả định balance đã trừ đơn Pending Approval (OrangeHRM 5.x). Nếu thực tế khác, sửa lại kỳ vọng.
    assert read_balance(page) == pytest.approx(before - 1)


# ======================= F04.4. Kiểm tra dữ liệu nhập =======================
@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Để Leave Type \"-- Select --\".\n"
        "4. Nhập From Date = To Date = 2026-12-14.\n"
        "5. Click [Apply]."
    ),
    expected=(
        "1. Hiển thị lỗi \"Required\" dưới Leave Type.\n"
        "2. Không tạo đơn."
    ),
)
def test_LEV_APPLY_016_khong_chon_leave_type(page):
    "LEV_APPLY_016 | Không chọn Leave Type"
    need_form(page)
    set_date(page, "From Date", "2026-12-14")
    set_date(page, "To Date", "2026-12-14")
    submit(page)
    expect(h.field_error(page, "Leave Type")).to_contain_text("Required")
    no_success_toast(page)


@pytest.mark.tc(
    steps=(
        "KB1 - Để trống From Date:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn Leave Type \"CAN - Vacation\".\n"
        "4. Để trống From Date, To Date.\n"
        "5. Click [Apply].\n"
        "KB2 - Để trống To Date:\n"
        "1. Chọn \"CAN - Vacation\", nhập From Date = 2026-12-14.\n"
        "2. Xóa nội dung To Date.\n"
        "3. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hiển thị lỗi \"Required\" dưới From Date.\n"
        "2. Không tạo đơn.\n"
        "KB2:\n"
        "1. Hiển thị lỗi \"Required\" dưới To Date.\n"
        "2. Không tạo đơn."
    ),
)
def test_LEV_APPLY_017_de_trong_from_to_date(page):
    "LEV_APPLY_017 | Để trống From Date hoặc To Date"
    # KB1
    need_form(page)
    select_type(page, VACATION)
    h.input(page, "From Date").fill("")
    h.input(page, "To Date").fill("")
    submit(page)
    expect(h.field_error(page, "From Date")).to_contain_text("Required")
    no_success_toast(page)

    # KB2
    open_apply(page)
    select_type(page, VACATION)
    set_date(page, "From Date", "2026-12-14")
    h.input(page, "To Date").fill("")
    submit(page)
    expect(h.field_error(page, "To Date")).to_contain_text("Required")
    no_success_toast(page)


@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = 2026-12-16, To Date = 2026-12-15.\n"
        "5. Click [Apply]."
    ),
    expected=(
        "1. Hiển thị lỗi \"To date should be after from date\".\n"
        "2. Không tạo đơn."
    ),
)
def test_LEV_APPLY_018_to_date_truoc_from_date(page):
    "LEV_APPLY_018 | To Date trước From Date"
    open_apply(page)
    select_type(page, VACATION)
    set_date(page, "From Date", "2026-12-16")
    set_date(page, "To Date", "2026-12-15")
    submit(page)
    expect(h.field_error(page, "To Date")).to_contain_text(re.compile("after from date", re.I))
    no_success_toast(page)


@pytest.mark.tc(
    steps=(
        "KB1 - From Date sai định dạng (dd/mm/yyyy):\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = 16/12/2026.\n"
        "5. Click [Apply].\n"
        "KB2 - Nhập ngày không tồn tại (2026-02-30):\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-02-30.\n"
        "3. Click [Apply].\n"
        "KB3 - Nhập chữ cái vào ô ngày:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = abc.\n"
        "3. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hiển thị lỗi \"Should be a valid date in yyyy-mm-dd format\".\n"
        "2. Không tạo đơn.\n"
        "KB2:\n"
        "1. Hiển thị lỗi định dạng ngày không hợp lệ.\n"
        "2. Không tạo đơn.\n"
        "KB3:\n"
        "1. Hiển thị lỗi định dạng ngày không hợp lệ.\n"
        "2. Không tạo đơn."
    ),
)
def test_LEV_APPLY_019_from_date_sai_dinh_dang(page):
    "LEV_APPLY_019 | From Date sai định dạng (dd/mm/yyyy, ngày không tồn tại, chữ cái)"
    for bad in ("16/12/2026", "2026-02-30", "abc"):  # KB1, KB2, KB3
        open_apply(page)
        select_type(page, VACATION)
        set_date(page, "From Date", bad)
        submit(page)
        expect(h.field_error(page, "From Date")).to_contain_text(re.compile("valid date", re.I))
        no_success_toast(page)


@pytest.mark.tc(
    steps=(
        "KB1 - Chọn ngày bằng date picker:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Click biểu tượng lịch ở From Date.\n"
        "4. Chọn ngày 2026-12-17.\n"
        "KB2 - To Date tự điền khi chọn From Date:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-12-17."
    ),
    expected=(
        "KB1:\n"
        "1. Lịch hiển thị đúng tháng; ngày hôm nay được đánh dấu.\n"
        "2. Ô From Date điền đúng định dạng yyyy-mm-dd.\n"
        "KB2:\n"
        "1. To Date tự động bằng From Date.\n"
        "2. Hiển thị trường Duration cho đơn 1 ngày."
    ),
)
def test_LEV_APPLY_020_date_picker_to_date_tu_dien(page):
    "LEV_APPLY_020 | Chọn ngày bằng date picker và To Date tự điền khi chọn From Date"
    # KB1
    open_apply(page)
    h.group(page, "From Date").locator(".oxd-date-input-icon").click()
    expect(page.locator(".oxd-calendar-wrapper")).to_be_visible()
    assert page.locator(".oxd-calendar-wrapper [class*='today']").count() >= 1, "Khong thay danh dau ngay hom nay"
    page.keyboard.press("Escape")
    pick_calendar_date(page, "From Date", 2026, 12, 17)
    expect(h.input(page, "From Date")).to_have_value(fmt("2026-12-17"))

    # KB2
    open_apply(page)
    select_type(page, VACATION)
    set_date(page, "From Date", "2026-12-17")
    expect(h.input(page, "To Date")).to_have_value(fmt("2026-12-17"))
    expect(h.group(page, "Duration")).to_be_visible()


# ---------- Comments ----------
@pytest.mark.tc(
    steps=(
        "KB1 - Comments đúng 250 ký tự:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-10.\n"
        "4. Nhập Comments gồm đúng 250 ký tự.\n"
        "5. Click [Apply].\n"
        "KB2 - Comments 251 ký tự:\n"
        "1. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-10.\n"
        "2. Nhập Comments gồm 251 ký tự.\n"
        "3. Click [Apply].\n"
        "KB3 - Comments chứa tiếng Việt và ký tự đặc biệt:\n"
        "1. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-09.\n"
        "2. Nhập Comments \"Nghỉ khám bệnh @#$% – Đà Nẵng\".\n"
        "3. Click [Apply], mở lại đơn ở My Leave.\n"
        "KB4 - Comments chỉ gồm khoảng trắng:\n"
        "1. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-03.\n"
        "2. Nhập Comments gồm 5 dấu cách.\n"
        "3. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Tạo đơn thành công, Comments được lưu đầy đủ.\n"
        "KB2:\n"
        "1. Hiển thị lỗi \"Should not exceed 250 characters\".\n"
        "2. Không tạo đơn.\n"
        "KB3:\n"
        "1. Tạo đơn thành công.\n"
        "2. Comments hiển thị đúng, không lỗi font/mã hóa.\n"
        "KB4:\n"
        "1. Hệ thống xử lý như để trống Comments (tạo đơn thành công) hoặc báo lỗi hợp lý; không lỗi hệ thống."
    ),
)
def test_LEV_APPLY_021_comments_bien_ky_tu_dac_biet(page, fresh):
    "LEV_APPLY_021 | Comments biên 250/251 ký tự, tiếng Việt - ký tự đặc biệt và chỉ gồm khoảng trắng"
    # KB1
    apply_ok(page, VACATION, "2026-12-10", duration="Full Day", comments=h.long_text(250))
    expect(my_leave_row(page, "2026-12-10")).to_contain_text("Pending Approval")

    # KB2
    open_apply(page)
    fill_apply(page, VACATION, "2026-12-10", duration="Full Day", comments=h.long_text(251))
    submit(page)
    expect(h.field_error(page, "Comments")).to_contain_text("exceed 250 characters")
    no_success_toast(page)

    # KB3
    text = "Nghỉ khám bệnh @#$% – Đà Nẵng"
    apply_ok(page, VACATION, "2026-12-09", duration="Full Day", comments=text)
    row = my_leave_row(page, "2026-12-09")
    assert text in cell(page, row, "Comments")

    # KB4 - [Q4] Chấp nhận cả 2 hành vi: tạo thành công hoặc báo lỗi validate hợp lý
    open_apply(page)
    fill_apply(page, VACATION, "2026-12-03", duration="Full Day", comments="     ")
    submit(page)
    expect(page.locator(".oxd-toast, .oxd-input-field-error-message").first).to_be_visible()
    assert not BAD_TEXT.search(page.locator("body").inner_text())


@pytest.mark.tc(
    steps=(
        "KB1 - Comments chứa thẻ script (XSS):\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-08.\n"
        "4. Nhập Comments <script>alert('xss')</script>.\n"
        "5. Click [Apply], mở lại đơn ở My Leave và Leave List.\n"
        "KB2 - Comments chứa câu lệnh SQL:\n"
        "1. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-04.\n"
        "2. Nhập Comments ' OR '1'='1'; --.\n"
        "3. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Chuỗi được lưu/hiển thị như văn bản thường.\n"
        "2. Không thực thi script, không xuất hiện popup.\n"
        "KB2:\n"
        "1. Chuỗi được xử lý như văn bản thường.\n"
        "2. Không lộ lỗi SQL/hệ thống."
    ),
)
def test_LEV_APPLY_022_comments_xss_sql(page, fresh):
    "LEV_APPLY_022 | Comments chứa thẻ script (XSS) và câu lệnh SQL"
    # KB1
    payload = "<script>alert('xss')</script>"
    opened = {"v": False}

    def on_dialog(d):
        opened["v"] = True
        d.dismiss()

    page.on("dialog", on_dialog)
    apply_ok(page, VACATION, "2026-12-08", duration="Full Day", comments=payload)
    row = my_leave_row(page, "2026-12-08")
    assert payload in cell(page, row, "Comments")  # hiển thị như văn bản thường
    leave_list_search(page, "2026-12-01", "2026-12-31", ["Pending Approval"])
    page.wait_for_timeout(500)
    assert opened["v"] is False

    # KB2
    sql = "' OR '1'='1'; --"
    apply_ok(page, VACATION, "2026-12-04", duration="Full Day", comments=sql)
    row = my_leave_row(page, "2026-12-04")
    assert sql in cell(page, row, "Comments")
    assert not BAD_TEXT.search(page.locator("body").inner_text())


# ======================= F04.5. Ràng buộc nghiệp vụ =======================
@pytest.mark.tc(
    steps=(
        "1. Pre: nhân viên có \"CAN - Personal\" = 1 ngày.\n"
        "2. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "3. Vào menu Leave > Apply.\n"
        "4. Chọn \"CAN - Personal\".\n"
        "5. Nhập From Date = To Date = 2026-12-01, Duration \"Full Day\".\n"
        "6. Click [Apply]."
    ),
    expected=(
        "1. Tạo đơn thành công.\n"
        "2. Leave Balance của CAN - Personal còn 0.00 (theo quy tắc hệ thống)."
    ),
)
def test_LEV_APPLY_023_don_bang_so_du(browser, ess_one_day):
    "LEV_APPLY_023 | Tạo đơn đúng bằng số dư còn lại"
    ctx, pg = login_as(browser, ess_one_day)
    try:
        open_apply(pg)
        select_type(pg, PERSONAL)
        assert read_balance(pg) == pytest.approx(1.0)
        fill_apply(pg, PERSONAL, "2026-12-01", duration="Full Day")
        submit(pg)
        h.expect_success(pg)
        h.ready(pg)
        open_apply(pg)
        select_type(pg, PERSONAL)
        assert read_balance(pg) == pytest.approx(0.0)  # [Q2]
    finally:
        ctx.close()


@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn vượt số dư:\n"
        "1. Pre: đã thực hiện e01.\n"
        "2. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "3. Vào menu Leave > Apply.\n"
        "4. Chọn \"CAN - Personal\".\n"
        "5. Nhập From Date = To Date = 2026-12-02.\n"
        "6. Click [Apply].\n"
        "KB2 - Tạo đơn nhiều ngày vượt số dư:\n"
        "1. Pre: đã thực hiện e01.\n"
        "2. Chọn \"CAN - Personal\".\n"
        "3. Nhập From Date = 2026-12-03, To Date = 2026-12-04.\n"
        "4. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hệ thống từ chối tạo đơn và hiển thị thông báo vượt số dư.\n"
        "2. Không có đơn mới trong My Leave.\n"
        "KB2:\n"
        "1. Hệ thống từ chối tạo đơn và hiển thị thông báo vượt số dư."
    ),
)
def test_LEV_APPLY_024_don_vuot_so_du(browser, ess_one_day):
    "LEV_APPLY_024 | Tạo đơn vượt số dư (1 ngày và nhiều ngày)"
    ctx, pg = login_as(browser, ess_one_day)
    try:
        exhaust_personal(pg)  # Pre e01: số dư Personal = 0

        # KB1
        open_apply(pg)
        fill_apply(pg, PERSONAL, "2026-12-02")
        submit(pg)
        expect_rejected(pg, "not sufficient|insufficient|balance")
        assert search_my_leave(pg, "2026-12-02", "2026-12-02", ("Pending Approval", "Scheduled")) == 0

        # KB2
        open_apply(pg)
        fill_apply(pg, PERSONAL, "2026-12-03", to="2026-12-04", partial="None")
        submit(pg)
        expect_rejected(pg, "not sufficient|insufficient|balance")
    finally:
        ctx.close()


@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = To Date = 2026-11-02 (đã có đơn từ c01).\n"
        "5. Click [Apply]."
    ),
    expected=(
        "1. Hệ thống từ chối, hiển thị thông báo đơn trùng (Overlapping Leave Request(s) Found).\n"
        "2. Không tạo đơn mới."
    ),
)
def test_LEV_APPLY_025_trung_don_pending(page, fresh):
    "LEV_APPLY_025 | Tạo đơn trùng ngày với đơn đang Pending Approval"
    apply_ok(page, VACATION, "2026-11-02", duration="Full Day", comments="Nghỉ việc riêng")
    open_apply(page)
    fill_apply(page, VACATION, "2026-11-02")
    submit(page)
    expect_rejected(page, "Overlapping Leave Request")
    search_my_leave(page, RANGE_FROM, RANGE_TO)
    assert active_rows(page, "2026-11-02").count() == 1


@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn nửa ngày trùng ngày đã có đơn Full Day:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = To Date = 2026-11-02, Duration \"Half Day - Morning\".\n"
        "5. Click [Apply].\n"
        "KB2 - Khoảng ngày bao trùm ngày đã có đơn:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-10-30, To Date = 2026-11-03.\n"
        "3. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hệ thống từ chối, hiển thị thông báo đơn trùng.\n"
        "KB2:\n"
        "1. Hệ thống từ chối, hiển thị thông báo đơn trùng."
    ),
)
def test_LEV_APPLY_026_trung_don_nua_ngay_bao_trum(page, fresh):
    "LEV_APPLY_026 | Tạo đơn trùng ngày: nửa ngày trùng đơn Full Day, khoảng ngày bao trùm đơn đã có"
    # Pre: đã có đơn Full Day ngày 2026-11-02
    apply_ok(page, VACATION, "2026-11-02", duration="Full Day")

    # KB1
    open_apply(page)
    fill_apply(page, VACATION, "2026-11-02", duration="Half Day - Morning")
    submit(page)
    expect_rejected(page, "Overlapping Leave Request")

    # KB2
    open_apply(page)
    fill_apply(page, VACATION, "2026-10-30", to="2026-11-03", partial="None")
    submit(page)
    expect_rejected(page, "Overlapping Leave Request")


@pytest.mark.tc(
    steps=(
        "1. Pre: đơn ngày 2026-11-03 đã bị Reject (k01).\n"
        "2. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "3. Vào menu Leave > Apply.\n"
        "4. Chọn \"CAN - Vacation\".\n"
        "5. Nhập From Date = To Date = 2026-11-03.\n"
        "6. Click [Apply]."
    ),
    expected="1. Tạo đơn thành công (đơn Rejected không gây trùng).",
)
def test_LEV_APPLY_027_tao_lai_sau_reject(page, browser, ess_vac):
    "LEV_APPLY_027 | Tạo lại đơn cùng ngày với đơn đã bị Reject"
    ctx, pg = login_as(browser, ess_vac)
    try:
        apply_ok(pg, VACATION, "2026-11-03", duration="Full Day")
        # Pre (k01): Admin từ chối đơn vừa tạo
        leave_list_search(page, "2026-11-01", "2026-11-30", ["Pending Approval"], employee=ess_vac["full"])
        row = h.rows(page).filter(has_text=fmt("2026-11-03")).first
        expect(row).to_be_visible()
        row.locator("button", has_text="Reject").click()
        h.expect_success(page)
        # Tạo lại đơn cùng ngày: không bị coi là trùng
        apply_ok(pg, VACATION, "2026-11-03", duration="Full Day")
    finally:
        ctx.close()


@pytest.mark.tc(
    steps=(
        "KB1 - Tạo đơn vào ngày thứ Bảy:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\".\n"
        "4. Nhập From Date = To Date = 2026-11-07 (thứ Bảy).\n"
        "5. Click [Apply].\n"
        "KB2 - Tạo đơn từ thứ Bảy đến Chủ nhật:\n"
        "1. Chọn \"CAN - Vacation\".\n"
        "2. Nhập From Date = 2026-11-07, To Date = 2026-11-08.\n"
        "3. Click [Apply].\n"
        "KB3 - Tạo đơn vào ngày lễ đã cấu hình:\n"
        "1. Pre: Admin thêm holiday 2026-12-25 tại Leave > Configure > Holidays.\n"
        "2. Chọn \"CAN - Vacation\".\n"
        "3. Nhập From Date = To Date = 2026-12-25.\n"
        "4. Click [Apply]."
    ),
    expected=(
        "KB1:\n"
        "1. Hệ thống từ chối, thông báo không có ngày làm việc được chọn (No Working Days Selected).\n"
        "2. Không tạo đơn.\n"
        "KB2:\n"
        "1. Hệ thống từ chối, thông báo không có ngày làm việc được chọn.\n"
        "KB3:\n"
        "1. Hệ thống từ chối do ngày lễ không phải ngày làm việc."
    ),
)
def test_LEV_APPLY_028_ngay_khong_lam_viec(page, fresh):
    "LEV_APPLY_028 | Tạo đơn vào ngày không làm việc (thứ Bảy, thứ Bảy - Chủ nhật, ngày lễ)"
    # KB1
    open_apply(page)
    fill_apply(page, VACATION, "2026-11-07")
    submit(page)
    expect_rejected(page, "No Working Days")

    # KB2
    open_apply(page)
    fill_apply(page, VACATION, "2026-11-07", to="2026-11-08", partial="None")
    submit(page)
    expect_rejected(page, "No Working Days")

    # KB3 - Pre: thêm holiday 2026-12-25
    name = h.uniq("G10Holiday")
    h.go(page, "/leave/saveHolidays")
    h.input(page, "Name").fill(name)
    set_date(page, "Date", "2026-12-25")
    created = page.get_by_text("Already exists").count() == 0
    if created:  # nếu ngày đó đã có holiday sẵn trên demo thì dùng luôn, không tạo/xoá
        h.btn(page, "Save").click()
        h.expect_success(page)
    try:
        open_apply(page)
        fill_apply(page, VACATION, "2026-12-25")
        submit(page)
        expect_rejected(page, "No Working Days|Holiday")
    finally:
        if created:
            h.go(page, "/leave/viewHolidayList")
            h.delete_row(page, name)


# ---------- Thao tác và bảo mật ----------
@pytest.mark.tc(
    steps=(
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\", From Date = To Date = 2026-12-07.\n"
        "4. Click đúp nhanh vào [Apply]."
    ),
    expected=(
        "1. Chỉ tạo 1 đơn duy nhất.\n"
        "2. Không báo lỗi hệ thống."
    ),
)
def test_LEV_APPLY_029_click_dup_apply(page, fresh):
    "LEV_APPLY_029 | Click đúp nút [Apply]"
    open_apply(page)
    fill_apply(page, VACATION, "2026-12-07", duration="Full Day")
    h.btn(page, "Apply").dblclick()
    h.ready(page)
    page.wait_for_timeout(1500)
    assert not BAD_TEXT.search(page.locator("body").inner_text())
    search_my_leave(page, RANGE_FROM, RANGE_TO)
    assert active_rows(page, "2026-12-07").count() == 1


@pytest.mark.tc(
    steps=(
        "KB1 - Giữ dữ liệu đã nhập khi gặp lỗi validation:\n"
        "1. Đăng nhập bằng tài khoản ESS (ess_han / Test@12345).\n"
        "2. Vào menu Leave > Apply.\n"
        "3. Chọn \"CAN - Vacation\", nhập Comments \"Test\", To Date trước From Date.\n"
        "4. Click [Apply].\n"
        "KB2 - Rời form khi đang nhập dở:\n"
        "1. Chọn Leave Type, nhập ngày và Comments (chưa Apply).\n"
        "2. Chuyển sang My Leave rồi quay lại Apply."
    ),
    expected=(
        "KB1:\n"
        "1. Hiển thị lỗi; các dữ liệu đã nhập vẫn được giữ nguyên.\n"
        "KB2:\n"
        "1. Không tạo đơn.\n"
        "2. Form quay về trạng thái ban đầu."
    ),
)
def test_LEV_APPLY_030_giu_du_lieu_khi_loi(page, fresh):
    "LEV_APPLY_030 | Giữ dữ liệu đã nhập khi lỗi validation và khi rời form đang nhập dở"
    # KB1
    open_apply(page)
    select_type(page, VACATION)
    set_date(page, "From Date", "2026-12-16")
    set_date(page, "To Date", "2026-12-15")
    h.input(page, "Comments").fill("Test")
    submit(page)
    expect(h.field_error(page, "To Date")).to_be_visible()
    assert VACATION in h.selected_text(page, "Leave Type")
    expect(h.input(page, "From Date")).to_have_value(fmt("2026-12-16"))
    expect(h.input(page, "To Date")).to_have_value(fmt("2026-12-15"))
    expect(h.input(page, "Comments")).to_have_value("Test")

    # KB2
    open_apply(page)
    fill_apply(page, VACATION, "2026-12-11", duration="Full Day", comments="Dang nhap do")
    h.open_tab(page, "My Leave")
    h.open_tab(page, "Apply")
    expect(page).to_have_url(re.compile(r"leave/applyLeave"))
    assert "Select" in h.selected_text(page, "Leave Type")
    expect(h.input(page, "From Date")).to_have_value("")
    expect(h.input(page, "Comments")).to_have_value("")
    search_my_leave(page, RANGE_FROM, RANGE_TO, ("Pending Approval", "Scheduled"))
    assert active_rows(page, "2026-12-11").count() == 0